package com.student.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DbUtil {
	public static Connection dbConn()throws ClassNotFoundException, SQLException {
		
		Class.forName(DbConstantPool.DRIVER_CLASS);
		Connection Conn = DriverManager.getConnection(DbConstantPool.DB_URL,DbConstantPool.USERNAME,DbConstantPool.PASSWORD);
		return Conn;
	}

}
